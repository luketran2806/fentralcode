const express = require('express');
const multer = require('multer');
const csvParser = require('csv-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

// Multer setup for handling file uploads
const upload = multer({ dest: 'uploads/' });

// Serve static files (HTML, JS, CSS)
app.use(express.static('public'));

// Route to upload and parse CSV for first tool
app.post('/upload-csv-1', upload.single('csvFile1'), (req, res) => {
    const results = [];
    const filePath = path.join(__dirname, req.file.path);

    fs.createReadStream(filePath)
        .pipe(csvParser())
        .on('data', (data) => results.push(data))
        .on('end', () => {
            fs.unlinkSync(filePath); // Delete the file after processing
            res.json(results); // Send the parsed CSV data to the client
        });
});

// Route to upload and parse CSV for second tool
app.post('/upload-csv-2', upload.single('csvFile2'), (req, res) => {
    const results = [];
    const filePath = path.join(__dirname, req.file.path);

    fs.createReadStream(filePath)
        .pipe(csvParser())
        .on('data', (data) => results.push(data))
        .on('end', () => {
            fs.unlinkSync(filePath); // Delete the file after processing
            res.json(results); // Send the parsed CSV data to the client
        });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
